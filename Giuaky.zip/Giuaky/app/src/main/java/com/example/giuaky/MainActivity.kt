package com.example.giuaky

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class MainActivity : AppCompatActivity() {

    private lateinit var edName : EditText
    private lateinit var edEmail : EditText
    private lateinit var btnAdd : Button
    private lateinit var btnView : Button
    private lateinit var btnUpdate : Button
    private lateinit var btnLogin : Button
    private lateinit var sqLiteHelper: SQLiteHelper
    private lateinit var recyclerView: RecyclerView
    private var adapter: StudentAdapter? = null
    private var std: StudentModel? =null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        initView()
        initRecyclerVew()
        sqLiteHelper=SQLiteHelper(this)
        btnAdd.setOnClickListener{ addStudent ()

        }
        btnLogin.setOnClickListener{ addStudent ()
            startActivity(Intent(this,ViewActivity::class.java))
        }
        btnView.setOnClickListener{ getStudent ()}
        btnUpdate.setOnClickListener{ updateStudent ()}


        adapter?.setOnClickitem {
            Toast.makeText(this,it.name,Toast.LENGTH_SHORT).show()
            edName.setText(it.name)
            edEmail.setText(it.email)
            std=it
        }
        adapter?.onClickDeleteItem {
deleteStudent(it.id )
        }

    }
    private fun deleteStudent(id:Int){
        val builder=AlertDialog.Builder(this)
        builder.setMessage("Are you sure you want delete item?")
        builder.setCancelable(true)
        builder.setPositiveButton("yes"){dialog ,_->
            sqLiteHelper.deleteId(id)
            getStudent()
            dialog.dismiss()
        }
        builder.setNegativeButton("No"){dialog ,_->
            dialog.dismiss()
        }
        val alert=builder.create()
        alert.show()

    }

    private fun updateStudent() {
        val name=edName.text.toString()
        val email=edEmail.text.toString()

        if(name==std?.name && email==std?.email){
            Toast.makeText(this,"Record not change",Toast.LENGTH_SHORT).show()
            return
        }
        if(std==null) {return}

            val  std=StudentModel(id=std!!.id,name=name, email = email)
            val status =sqLiteHelper.update(std)
            if(status>-1){
                Toast.makeText(this,"update success",Toast.LENGTH_SHORT).show()
                clearEditText()
                getStudent()
            }
            else{
                Toast.makeText(this,"Update failed",Toast.LENGTH_SHORT).show()
            }

        }


    private fun getStudent() {
        val stdList=sqLiteHelper.getAllStudent()
        Log.e("ppp" ,"${stdList.size}")
        adapter?.addItems(stdList)

    }

    private fun  addStudent(){
        val name=edName.text.toString()
        val email=edEmail.text.toString()

        if(name.isEmpty() || email.isEmpty()){
            Toast.makeText(this,"please enter requried field",Toast.LENGTH_SHORT).show()
        }else{
            val  std=StudentModel(name=name, email = email)
            val status =sqLiteHelper.insertStudent(std)
            if(status>-1){
                Toast.makeText(this,"Đăng nhập thành công",Toast.LENGTH_SHORT).show()
                clearEditText()
                getStudent()
            }
            else{
                Toast.makeText(this,"Record not saved",Toast.LENGTH_SHORT).show()
            }

        }
    }

    private fun clearEditText() {
        edEmail.setText("")
        edName.setText("")
        edName.requestFocus()
    }
    private fun initRecyclerVew(){
        recyclerView.layoutManager=LinearLayoutManager(this)
        adapter=StudentAdapter()
        recyclerView.adapter=adapter
    }
    private fun initView() {
        edName=findViewById(R.id.edName)
        edEmail=findViewById(R.id.edEmail)
        btnAdd=findViewById(R.id.btnAdd)
        btnView=findViewById(R.id.btnView)
        btnUpdate=findViewById(R.id.btnUpdate)
        btnLogin=findViewById(R.id.btnLogin)
        recyclerView=findViewById(R.id.recyclerView)
    }


}